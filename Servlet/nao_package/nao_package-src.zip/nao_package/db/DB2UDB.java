package nao_package.db;

/**********************************************************************
 * �f�[�^�x�[�X�ڑ� DB2UDB.java
 **********************************************************************/
public class DB2UDB extends Database    {
    public static String TYPE2 = "COM.ibm.db2.jdbc.app.DB2Driver";  // �A�v���P�[�V�����p
    public static String TYPE3 = "COM.ibm.db2.jdbc.net.DB2Driver";  // �A�v���b�g�p

    /*
    public DB2UDB() {
        this("sample", "db2inst1", "db2udb", TYPE2);
    }
    */

    /*****************************************************************
     * �������̃R���X�g���N�^�B�e�p�����[�^��ݒ肷��B
     * 
     * @param dbName �f�[�^�x�[�X�E�C���X�^���X����
     * @param usr    �C���X�^���X�E�I�[�i�[�̃��[�U�[��
     * @param pas    �C���X�^���X�E�I�[�i�[�̃p�X���[�h
     * @param mode   TYPE2 OR TYPE3
     *****************************************************************/
    public DB2UDB(String dbName, String usr, String pas, String type) {
        if (isDB2V8()) {
            driver = "com.ibm.db2.jcc.DB2Driver";
            if (TYPE2.equals(type)) {
                url = "jdbc:db2:" + dbName;
            } else {
                url = "jdbc:db2:" + db2v8type4(dbName);
            }
        } else {
            driver = type;
            url = "jdbc:db2:" + dbName;
        }
        user = usr;
        pass = pas;
        System.out.println("url=" + url);
    }

    public DB2UDB() {   // �T�[�u���b�g����
        this("gakumudb", "db2inst1", "db2inst1", DB2UDB.TYPE2);
    }

    private static Boolean ISDB2V8 = null;

    private static synchronized boolean isDB2V8() {
        if (null == ISDB2V8) {
            String property = null;
            try {
                property = System.getProperty("nao_package.db.DB2UDB.isDB2V8");
            } catch (final RuntimeException e) {
                System.err.println(e.getMessage());
            }
            System.out.println("�V�X�e���v���p�e�B�̒l nao_package.db.DB2UDB.isDB2V8=" + property);
            if (null == property) {
                ISDB2V8 = Boolean.FALSE;
                try {
                    Class.forName("com.ibm.db2.jcc.DB2Driver");
                    ISDB2V8 = Boolean.TRUE;
                } catch (final Throwable e) {
                    ;
                }
            } else {
                ISDB2V8 = property.equalsIgnoreCase("true") ? Boolean.TRUE : Boolean.FALSE;
            }

            System.out.println("ISDB2V8=" + ISDB2V8);
        }

        return ISDB2V8.booleanValue();
    }

    private static String db2v8type4(final String url) {
        // "//host/dbname" �� "//host:50000/dbname" �ɒu������
        if (null != url && url.startsWith("//")) {
            final int pos = url.indexOf('/', 2);
            if (-1 == pos) {
                return url;
            }
            final String host = url.substring(0, pos);
            final String dbname = url.substring(pos, url.length());
            return host + ":50000" + dbname;
        } else {
            return url;
        }
    }
}
