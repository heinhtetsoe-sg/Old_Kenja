package nao_package;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class CalendarFrame extends JDialog {
  JPanel contentPane;
  BorderLayout borderLayout = new BorderLayout();
  CalendarModel calendarModel;
  JPanel hedPanel = new JPanel();   // �����E�O���{�^���Ȃǂ�����p�l��
  JPanel bottomPanel = new JPanel();    // OK, Cancel
  
  JScrollPane jScrollPane = new JScrollPane();
  TitledBorder titledBorder1;
  JTable jTable = new JTable();
  JTableHeader header = jTable.getTableHeader();
  
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField YearField = new JTextField();
  JTextField MonthField = new JTextField();
  JButton beforeMonthButton = new JButton();
  JButton nextMonthButton = new JButton();
  JButton beforeYearButton = new JButton();
  JButton nextYearButton = new JButton();
  
  JButton submitButton = new JButton("OK");
  JButton cancelButton = new JButton("Cancel");
  //
  public Date ymd;

  //�t���[���̍\�z
  public CalendarFrame() {
    this(new java.util.Date(), null, false);
  }

  public CalendarFrame(Frame parent, boolean modal) {
    this(new java.util.Date(), parent, modal);
  }

  public CalendarFrame(java.util.Date ddd, Frame parent, boolean modal) {
    super(parent, modal);
    ymd = ddd;
    calendarModel = new CalendarModel(ymd);
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
      fieldInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  // ���t���Z�b�g����B
  public void setDate( Date ddd ){
    ymd = ddd;
    calendarModel = new CalendarModel(ymd);
    jTable.setModel( calendarModel );
    // ���j�͐ԁA�y�j�͐̃t�H���g��
    DefaultTableColumnModel dtcm = (DefaultTableColumnModel)jTable.getColumnModel();    // �J�������f���̒��o
    for( int i=0; i<jTable.getColumnCount(); i++ ){
        TableColumn tColumn = dtcm.getColumn(i);
        tColumn.setCellRenderer( new DayRenderer2() );
    }
    fieldInit();
    this.update(this.getGraphics()); // �t���[���̍ĕ`��
  }

  // ���t��Ԃ�
  public java.util.Date getDate(){
    return ymd;
  }

  //�R���|�[�l���g�̏�����
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder("");
    contentPane.setLayout(borderLayout);
    this.setSize(new Dimension(400, 320));
    this.setTitle("�J�����_�[");

    hedPanel.setMaximumSize(new Dimension(32767, 100));
    hedPanel.setMinimumSize(new Dimension(10, 100));
    hedPanel.setPreferredSize(new Dimension(10, 30));
    jScrollPane.setMinimumSize(new Dimension(24, 200));
    jScrollPane.setPreferredSize(new Dimension(4, 200));
    MonthField.setMinimumSize(new Dimension(50, 21));
    MonthField.setPreferredSize(new Dimension(50, 21));
    MonthField.setEditable(false);
    jLabel1.setText("�N");
    jLabel2.setText("��");
    
    // �O���ړ��{�^��
    beforeMonthButton.setBorder(BorderFactory.createRaisedBevelBorder());
    beforeMonthButton.setText("�@< �O���@");
    beforeMonthButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        beforeMonth_actionPerformed(e);
      }
    });

    // �����ړ��{�^��
    nextMonthButton.setBorder(BorderFactory.createRaisedBevelBorder());
    nextMonthButton.setText("�@���� >�@");
    nextMonthButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        nextMonth_actionPerformed(e);
      }
    });

    // �O�N�ړ��{�^��
    beforeYearButton.setBorder(BorderFactory.createRaisedBevelBorder());
    beforeYearButton.setText("<< �O�N");
    beforeYearButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        beforeYearButton_actionPerformed(e);
      }
    });

    // ���N�ړ��{�^��
    nextYearButton.setBorder(BorderFactory.createRaisedBevelBorder());
    nextYearButton.setText("���N >>");
    nextYearButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        nextYearButton_actionPerformed(e);
      }
    });

    // OK�{�^������
    submitButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        submit();
      }
    });

    // �L�����Z���{�^������
    cancelButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        hide();
      }
    });

    contentPane.setPreferredSize(new Dimension(10, 30));

    header.setReorderingAllowed(false);    // ��̏�����s����
    YearField.setMinimumSize(new Dimension(50, 21));
    YearField.setPreferredSize(new Dimension(50, 21));
    YearField.setEditable(false);
    jTable.setModel(calendarModel);

    // takaesu
    jTable.setCellSelectionEnabled(true);   // takaesu
    jTable.setSelectionMode( ListSelectionModel.SINGLE_SELECTION );
    jTable.addMouseListener( new java.awt.event.MouseAdapter() {
        public void mouseClicked(MouseEvent evnt){
            // �_�u���N���b�N���ꂽ���H
            if( evnt.getClickCount()==2 ){
                submit();
            }
        }
        
    });
    
    jTable.setRowHeight(40);
    contentPane.add(jScrollPane, BorderLayout.CENTER);
    jScrollPane.getViewport().add(jTable, null);
    contentPane.add(hedPanel, BorderLayout.NORTH);
    hedPanel.add(beforeYearButton, null);
    hedPanel.add(beforeMonthButton, null);
    hedPanel.add(YearField, null);
    hedPanel.add(jLabel1, null);
    hedPanel.add(MonthField, null);
    hedPanel.add(jLabel2, null);
    hedPanel.add(nextMonthButton, null);
    hedPanel.add(nextYearButton, null);

    bottomPanel.add(submitButton);
    bottomPanel.add(cancelButton);
    contentPane.add(bottomPanel, BorderLayout.SOUTH);

    // ���j�͐ԁA�y�j�͐̃t�H���g��
    DefaultTableColumnModel dtcm = (DefaultTableColumnModel)jTable.getColumnModel();    // �J�������f���̒��o
    for( int i=0; i<jTable.getColumnCount(); i++ ){
        TableColumn tColumn = dtcm.getColumn(i);
        tColumn.setCellRenderer( new DayRenderer2() );
    }

  }


  //�E�B���h�E������ꂽ�Ƃ��ɏI������悤�ɃI�[�o�[���C�h
/***
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }
***/

  /**
 * 
 */
protected void submit() {
    // �I�����ꂽ�s�A������ƂɔN�����𓾂�
    int row, col;
    row = jTable.getSelectedRow();
    col = jTable.getSelectedColumn();
    ymd = (Date)calendarModel.getValueAt(row, col);
    // �_�C�A���O���\��
    hide();
}

protected void fieldInit() {
    // ���FgetYear()�AgetMonth()��CalendarModel�Ǝ��ɒ�`���ꂽ���\�b�h�ł��B
    YearField.setText(String.valueOf(((CalendarModel )calendarModel).getYear()));
    MonthField.setText(String.valueOf(((CalendarModel )calendarModel).getMonth()));
  }

  void nextMonth_actionPerformed(ActionEvent e) {
    calendarModel.addMonth(1);
    fieldInit();
    this.update(this.getGraphics()); // �t���[���̍ĕ`��
  }

  void beforeMonth_actionPerformed(ActionEvent e) {
    calendarModel.addMonth(-1);
    fieldInit();
    this.update(this.getGraphics()); // �t���[���̍ĕ`��
  }

  void beforeYearButton_actionPerformed(ActionEvent e) {
      calendarModel.addMonth(-12);
      fieldInit();
      this.update(this.getGraphics()); // �t���[���̍ĕ`��
    }

  void nextYearButton_actionPerformed(ActionEvent e) {
      calendarModel.addMonth(12);
      fieldInit();
      this.update(this.getGraphics()); // �t���[���̍ĕ`��
  }

  // ���[�_���X�ɂ��Ȃ��B�i�p�����\�b�h�̃I�[�o�[���C�h�j
  // takaesu
  public boolean isModal(){
    return true;
  }

    /*
     * ���t�^������������Z�b�g���郌���_��
     */
    class DayRenderer2 extends DefaultTableCellRenderer
    {
        public Component getTableCellRendererComponent(
                JTable table,
                Object value,
                boolean isSelected,
                boolean hasFocus,
                int row, int column )
        {
            if( column==0 ){
                setForeground(Color.red);
            }
            else if( column==6 ){
                setForeground(Color.blue);
            }

            setHorizontalAlignment(SwingConstants.CENTER);

            return( super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column) );
        }

        public void setValue( Object value ){
            SimpleDateFormat sdf = new SimpleDateFormat("dd");
            super.setText( sdf.format((Date)value) );
        }
    }
}

