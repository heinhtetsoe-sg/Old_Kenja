package nao_package.svf;

import java.io.*;
import jp.co.fit.vfreport.*;

/*
 * Vrw32alp.java
 * ���V�X�e�� SVF for JavaEdition�̂`�k�o�d�l
 * '02.07.10
 * '03.06.12:�������́u���v�ȂǂɑΉ�
 */
public class Vrw32alp extends Vrw32
{
    public Vrw32alp(){
        super();
    }

    public int VrInit(){
        int sts = super.VrInit();
        if( sts != 0 ){
            System.out.println("===> VrInit():" + sts);
        }
        return sts;
    }

    public int VrSetSpoolFileStream( OutputStream ostream ){
        int sts = super.VrSetSpoolFileStream( ostream );
        if( sts != 0 ){
            System.out.println("===> VrSetSpoolFileStream():" + sts);
        }
        return sts;
    }

    public int VrSetForm( String s, int n ){
        int sts = super.VrSetForm( s, n );
        if( sts != 0 ){
            System.out.println("===> VrSetForm():" + sts);
        }
        return sts;
    }

    public int VrSetQuery( String s, String vrq, int n ){
        int sts = super.VrSetQuery( s, vrq, n );
        if( sts != 0 ){
            System.out.println("===> VrSetQuery(" + s + ", " + vrq + "):" + sts);
        }
        return sts;
    }

    public int VrReport(){
        int sts = super.VrReport();
        if( sts != 0 ){
            System.out.println("===> VrReport():" + sts);
        }
        return sts;
    }

    public int VrEndRecord(){
        int sts = super.VrEndRecord();
        if( sts != 0 ){
            System.out.println("===> VrEndRecord():" + sts);
        }
        return sts;
    }

    public int VrPrint(){
        int sts = super.VrPrint();
        if( sts != 0 ){
            System.out.println("===> VrPrint():" + sts);
        }
        return sts;
    }

    public int VrQuit(){
        int sts = super.VrQuit();
        if( sts != 0 ){
            System.out.println("===> VrQuit():" + sts);
        }
        return sts;
    }

    public int VrsOut(String field, String data) {
        if( data!=null ){
            data = data.replace('\uE2D3', '\u9AD9');  // ���i�����j
            data = data.replace('\uE1CC', '\uFA11');  // ��i�����j
            data = data.replace('\uE200', '\u6801');  // ���i��イ�j
            data = data.replace('\uE189', '\u4f39');  // �A�i����j
        }
 
        int sts = super.VrsOut(field, data);
        return sts;
    }

    public int VrsOutn(String field, int gyo, String data) {
        if( data!=null ){
            data = data.replace('\uE2D3', '\u9AD9');  // ���i�����j
            data = data.replace('\uE1CC', '\uFA11');  // ��i�����j
            data = data.replace('\uE200', '\u6801');  // ���i��イ�j
            data = data.replace('\uE189', '\u4f39');  // �A�i����j
        }
 
        int sts = super.VrsOutn(field, gyo, data);
        return sts;
    }
}
