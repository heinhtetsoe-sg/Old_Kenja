/**
 * Copyright (C)2004 dGIC Corporation.
 *
 * This file is part of djUnit plugin.
 *
 * djUnit plugin is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 *
 * djUnit plugin is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with djUnit plugin; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 *
 */
package jp.co.dgic.eclipse.jdt.internal.coverage.report;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

public class IndicatorLabel extends Canvas implements ICoverageLabel {

	private static final RGB RGB_GREEN = new RGB(0, 240, 0);
	private static final RGB RGB_RED = new RGB(224, 0, 0);
	private static final RGB RGB_GREEN_SHADOW = new RGB(0, 128, 0);
	private static final RGB RGB_RED_SHADOW = new RGB(128, 0, 0);
	private static final RGB RGB_GRAY = new RGB(128, 128, 128);

	private static final int MARGIN = 1;

	private double coverage;
	private CoverageLabel greenLabel;
	private CoverageLabel redLabel;
	private RGB backgroundRGB;

	public IndicatorLabel(Composite parent, double coverage) {
		super(parent, SWT.NONE);

		this.coverage = coverage;

		GridLayout gl = new GridLayout(2, false);
		gl.verticalSpacing = 0;
		gl.horizontalSpacing = 0;
		gl.marginHeight = MARGIN;
		gl.marginWidth = MARGIN;
		setLayout(gl);

		setBackground(new Color(getDisplay(), RGB_GRAY));


		greenLabel = new GreenLabel(this);
		redLabel = new RedLabel(this);
	}

	public void setLineNumber(int lineNumber) {
		if ((lineNumber % 2) == 0) {
			backgroundRGB = RGB_LINE_BACKGROUND;
		} else {
			backgroundRGB = RGB_BACKGROUND;
		}
		setBackground(new Color(getDisplay(), backgroundRGB));
	}

	protected void checkSubclass() {
	}

	public Point computeSize(int wHint, int hHint, boolean changed) {
		return getSize();
	}

	public String getText() {
		return "";
	}

	public void setText(String text) {
		return;
	}

	private void resize(int width, int height) {
		int labelWidth = width - MARGIN;
		int greenWidth = (int) ((double) labelWidth * coverage);
		int redWidth = labelWidth - greenWidth;
		int labelHeight = height - MARGIN;

		greenLabel.setSize(greenWidth, labelHeight);
		redLabel.setSize(redWidth, labelHeight);
	}

	public void setSize(int width, int height) {
		resize(width, height);
		super.setSize(width, height);
	}

	public void setSize(Point size) {
		resize(size.x, size.y);
		super.setSize(size);
	}

	private class CoverageLabel extends Label {

		public CoverageLabel(Composite parent) {
			super(parent, SWT.NONE);
		}

		public Point computeSize(int wHint, int hHint, boolean changed) {
			return getSize();
		}

		protected void checkSubclass() {
		}

	}

	private class GreenLabel extends CoverageLabel {

		public GreenLabel(Composite parent) {
			super(parent);
			setBackground(new Color(parent.getDisplay(), RGB_GREEN));

			addPaintListener(new PaintListener() {
				public void paintControl(PaintEvent e) {
					drawLine(e.gc);
				}
			});
		}

		private void drawLine(GC gc) {
			gc.setForeground(new Color(getDisplay(), RGB_GREEN_SHADOW));
			Rectangle r = getBounds();
			int[] pointArray = {r.width - 1, 0, r.width - 1, r.height - 1, 2, r.height - 1};
			gc.drawPolyline(pointArray);
			
			gc.setForeground(new Color(getDisplay(), backgroundRGB));
			gc.drawLine(0, r.height - 1, 1, r.height - 1);
			
		}
	}

	private class RedLabel extends CoverageLabel {

		public RedLabel(Composite parent) {
			super(parent);
			setBackground(new Color(parent.getDisplay(), RGB_RED));

			addPaintListener(new PaintListener() {
				public void paintControl(PaintEvent e) {
					drawLine(e.gc);
				}
			});
		}

		private void drawLine(GC gc) {
			gc.setForeground(new Color(getDisplay(), RGB_RED_SHADOW));
			Rectangle r = getBounds();
			int[] pointArray = {r.width - 1, 0, r.width - 1, r.height - 1, 0, r.height - 1};
			gc.drawPolyline(pointArray);
		}
	}

}
