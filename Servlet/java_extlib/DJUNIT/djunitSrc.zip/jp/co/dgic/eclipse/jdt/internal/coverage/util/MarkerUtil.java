/**
 * Copyright (C)2004 dGIC Corporation.
 *
 * This file is part of djUnit plugin.
 *
 * djUnit plugin is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 *
 * djUnit plugin is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with djUnit plugin; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 *
 */
package jp.co.dgic.eclipse.jdt.internal.coverage.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import jp.co.dgic.eclipse.jdt.internal.coverage.ui.CoveragemarkerDeleteProcess;
import jp.co.dgic.eclipse.jdt.internal.coverage.ui.MarkerCreator;
import jp.co.dgic.eclipse.jdt.internal.junit.ui.DJUnitMessages;
import jp.co.dgic.eclipse.jdt.internal.junit.ui.DJUnitPlugin;
import jp.co.dgic.testing.common.coverage.CoverageResultFactory;
import jp.co.dgic.testing.common.util.DJUnitUtil;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.IJavaProject;

import com.jcoverage.coverage.Instrumentation;

public class MarkerUtil {

	private static final int OS_NEW_LINE_CODE_LENGTH;

	static {
		String osName = System.getProperty("os.name");
		if (osName != null && osName.toLowerCase().indexOf("windows") >= 0) {
			OS_NEW_LINE_CODE_LENGTH = 2;
		} else {
			OS_NEW_LINE_CODE_LENGTH = 1;
		}
	}

	public static void setCoverageMark(IJavaProject javaProject) {
		setCoverageMark(javaProject, null);
	}

	public static void setCoverageMark(IJavaProject javaProject, IProgressMonitor monitor) {

		CoveragePluginUtil.setCoverageWorkingDirectory(javaProject.getProject());

		clearCoverageMarker(javaProject.getProject());

		Map m = CoverageResultFactory.getInstance().getInstrumentation();
		Iterator coverageKeys = m.keySet().iterator();

		int classCount = 1;
		int totalClass = m.size();

		String message = DJUnitMessages.getString("MarkerUtil.message.marking");

		if (monitor != null) {
			monitor.beginTask(message + " (" + totalClass + " classes)", totalClass);
		}

		while (coverageKeys.hasNext()) {
			if (monitor != null) {
				if (monitor.isCanceled()) {
					break;
				}
				monitor.setTaskName(message + " (" + classCount + "/" + totalClass + ")");
			}
			String key = (String) coverageKeys.next();
			Instrumentation i = (Instrumentation) m.get(key);
			try {
				IResource resource = javaProject.findType(DJUnitUtil.getJavaProjectType(key)).getResource();
				setMarker(resource, i, monitor);
			} catch (CoreException ce) {
				ce.printStackTrace();
			} catch (Throwable t) {
				DJUnitPlugin.log(new RuntimeException("[catch Throwable] at Key = " + key));
				DJUnitPlugin.log(t);
			}
			classCount++;
			if (monitor != null) {
				monitor.worked(1);
			}
		}

		if (monitor == null) {
			monitor.done();
		}
	}

	public static void clearCoverageMarker(IProject project) {
		//		try {
		//			project.deleteMarkers(CoverageMarker.MARKER_ID, true,
		// IResource.DEPTH_INFINITE);
		//		} catch (CoreException e) {
		//		}
		try {
			ResourcesPlugin.getWorkspace().run(new CoveragemarkerDeleteProcess(project), null);
		} catch (CoreException e) {
		}
	}

	private static void setMarker(IResource resource, Instrumentation i, IProgressMonitor monitor) throws CoreException {

		Map coverage = i.getCoverage();
		Set lineNumbers = i.getSourceLineNumbers();

		Map ranges = getLineRanges(resource);

		Iterator it = lineNumbers.iterator();
		int lineCount = 1;
		int totalLine = lineNumbers.size();
		while (it.hasNext()) {
			if (monitor != null) {
				if (monitor.isCanceled()) {
					break;
				}
				monitor.subTask(i.getSourceFileName() + "(" + lineCount + "/" + totalLine + ")");
			}
			Integer lineNumber = (Integer) it.next();
			if (coverage.containsKey(lineNumber)) {
				continue;
			}

			LineOffsetRange r = (LineOffsetRange) ranges.get(lineNumber);
			if (r == null) {
				r = new LineOffsetRange(-1, -1);
			}

			ResourcesPlugin.getWorkspace().run(new MarkerCreator(resource, lineNumber, r.getStartOffset(), r.getEndOffset()), null);

			lineCount++;
		}
	}

	private static HashMap getLineRanges(IResource resource) {
		HashMap ranges = new HashMap();
		InputStream in = null;
		BufferedReader reader = null;
		try {
			in = ((org.eclipse.core.internal.resources.File) resource).getContents();
			reader = new BufferedReader(new InputStreamReader(in));

			int l = 0;
			int offset = 0;
			int newLineCharLength = getNewLineCharLength(resource);
			while (true) {
				String line = reader.readLine();
				if (line == null)
					break;

				l++;

				int length = line.toCharArray().length;
				LineOffsetRange range = new LineOffsetRange(offset, offset + length);

				offset += (length + newLineCharLength);

				ranges.put(new Integer(l), range);
			}
		} catch (Throwable t) {
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
				}
			}
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
				}
			}
		}
		return ranges;
	}

	private static int getNewLineCharLength(IResource resource) throws CoreException {

		InputStream in = null;
		BufferedReader reader = null;

		try {
			in = ((org.eclipse.core.internal.resources.File) resource).getContents();
			reader = new BufferedReader(new InputStreamReader(in));

			int code = 0;
			while (true) {
				code = reader.read();
				if (code == (int) '\r' || code == (int) '\n') break;
			}

			if (code == (int) '\n') return 1;
			if (OS_NEW_LINE_CODE_LENGTH > 1) return 2;

			return 1;


		} catch (IOException e) {
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
				}
			}
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
				}
			}

		}

		return OS_NEW_LINE_CODE_LENGTH;
	}

	static class LineOffsetRange {
		private int startOffset;

		private int endOffset;

		public LineOffsetRange(int startOffset, int endOffset) {
			this.startOffset = startOffset;
			this.endOffset = endOffset;
		}

		public int getStartOffset() {
			return startOffset;
		}

		public int getEndOffset() {
			return endOffset;
		}
	}

}